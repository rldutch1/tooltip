tooltip
=======

My tooltip repsitory
<<<<<<< HEAD
This repo has a couple of tooltips that I have used. The tooltips are displayed from a DIV element and I initially learned how to do this by watching a YouTube video (http://www.youtube.com/watch?v=gJY8YUjFd58). 
=======
This repo has a couple of tooltips that I have used. The tooltips are displayed from the content of a DIV element and I initially learned how to do this by watching a YouTube video (http://www.youtube.com/watch?v=gJY8YUjFd58). 
>>>>>>> 871eade5bbb695b04ab504d0befb414fd7c9fee2
